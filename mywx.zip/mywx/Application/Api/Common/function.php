<?php

// 文本
function transmitText($object, $content)
{
    $xmlTpl = '<xml>
                <ToUserName><![CDATA[%s]]></ToUserName>
                <FromUserName><![CDATA[%s]]></FromUserName>
                <CreateTime><![CDATA[%s]]></CreateTime>
                <MsgType><![CDATA[text]]></MsgType>
                <Content><![CDATA[%s]]></Content>
            </xml>';
    $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), $content);
    return $result;
}

// 图片
function transmitImg($object, $PicUrl)
{
    $xmlTpl = '<xml>
                <ToUserName><![CDATA[%s]]></ToUserName>
                <FromUserName><![CDATA[%s]]></FromUserName>
                <CreateTime><![CDATA[%s]]></CreateTime>
                <MsgType><![CDATA[image]]></MsgType>
                <Image>
                <MediaId><![CDATA[%s]]></MediaId>
                </Image>
            </xml>';
    $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), $object->MediaId);
    return $result;
}

// 数据日志
function logger($log_content, $type = '用户')
{
    $max_size = 3000;
    $log_filename = './Wx/log.xml';
    if (file_exists($log_filename) and (abs(filesize($log_filename)) >
            $max_size)) {
        unlink($log_filename);
    }
    file_put_contents($log_filename, $type.date('Y-m-d H:i:s').'\n\r'.$log_content.'\n\r',
        FILE_APPEND);
    fclose($log_filename);
}

// 请求日志
function queryLog()
{
    $content = date('Y-m-d H:i:s')."\n\rremote_ip：".$_SERVER["REMOTE_ADDR"].
    "\n\r".$_SERVER["QUERY_STRING"]."\n\r\n\r";
    $max_size = 3000;
    $log_filename = './Wx/query.xml';
    if (file_exists($log_filename) and (abs(filesize($log_filename)) >
            $max_size)) {
        unlink($log_filename);
    }
    file_put_contents($log_filename, $content, FILE_APPEND);
    fclose($log_filename);
}

// 获取日志
function get_files_log($filename) {
    $url = $_SERVER['SERVER_NAME'].'/Wx/'.$filename;
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
}

// 获取access_token
function getToken(){
    $appid='wx9cdcaa96d8e5a46e';
    $appsecret='7b57f69ed6e5cd1ca15a5c4a346428fe';
    $file = file_get_contents('./Wx/access_token.json',true);
    $result = json_decode($file,true);
    if (time() > $result['expires']){
        $data = array();
        $data['access_token'] = getNewToken($appid,$appsecret);
        $data['expires']=time()+7000;
        $jsonStr =  json_encode($data);
        $fp = fopen('./Wx/access_token.json', 'w');
        fwrite($fp, $jsonStr);
        fclose($fp);
        return $data['access_token'];
    }else{
        return $result['access_token'];
    }
}

function getNewToken($appid,$appsecret){
    $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$appid}&secret={$appsecret}';
    $access_token_Arr =  get_curl($url);
    return $access_token_Arr['access_token'];
}

function get_curl($url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    curl_close($ch);
    return json_decode($data,true);
}

function post_curl($url, $postArr){
    $ch = curl_init();//初始化curl
    $header[] = 'content-type: text/html; charset=UTF-8';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);//设置header
    curl_setopt($ch, CURLOPT_URL,$url);//抓取指定网页
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postArr);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
    curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
    $data = curl_exec($ch);//运行curl
    curl_close($ch);
    return $data;
}