<?php
namespace Api\Controller;

use Think\Controller;

class IndexController extends Controller
{
    private $TOKEN = 'zero';
    private $access_token;

    public function __construct()
    {
        // 写入请求日志
        queryLog();
        // 获取token
        $this->access_token = getToken();
    }

    // 响应echostr、响应消息
    public function index()
    {
        $echostr = I('get.echostr', '', true);
        if(!empty($echostr)) {
            $this->valid($echostr);
        } else {
            $this->responseMsg();
        }
    }

    // 正确签名则原样返回echostr
    public function valid($echostr)
    {
        if($this->checkSignature()) {
            echo $echostr;
            exit;
        }
    }

    // 检查签名
    public function checkSignature()
    {
        $data = I('get.');
        $token = $this->TOKEN;
        $arr = array($token, $data['timestamp'], $data['nonce']);
        sort($arr);
        $arrTmp = implode($arr);
        $arrTmp = sha1($arrTmp);
        if($arrTmp == $data['signature']) {
            return true;
        } else {
            return false;
        }
    }

    // 响应消息
    public function responseMsg()
    {
        // PHP默认识别的数据类型是application/x-www.form-urlencoded,当Content-Type=application/json
        // 类型时无法通过 $_POST获取，但是使用 GLOBALS[‘HTTP_RAW_POST_DATA’]可以获取到。
        $postArr = $GLOBALS['HTTP_RAW_POST_DATA']; // PHP7中已经移除了这个全局变量，用 php://input 替代
        // 写入数据日志
        logger($postArr);
        if(!empty($postArr)) {
            // 把 XML 字符串载入对象中
            $postObj = simplexml_load_string($postArr, 'SimpleXMLElement',LIBXML_NOCDATA);
            // 去掉字符串两端的多余的空格
            $RX_TYPE = trim($postObj->MsgType);
            switch ($RX_TYPE) {
                case 'text':
                    $result = $this->receiveMsg($postObj);
                    break;

                case "event":
                    $result = $this->eventMsg($postObj);
                    break;

                case "image":
                    $result = $this->eventImg($postObj);
                    break;
                
                default:
                    $result = 'unknow msg type'.$RX_TYPE;
                    break;
            }
            echo $result;
        } else {
            echo '';
            exit;
        }
    }

    // 回复文本
    public function receiveMsg($object)
    {
        header('content-type: text/html; charset=UTF-8');
        $arr = array(
            'reqType'       => 0,
            'perception'    => array(
                'inputText'     => array(
                    'text'          => $object->Content,
                ),
            ),
            'userInfo'      => array(
                'apiKey'        => C('apiKey'),
                'userId'        => '1',
            )
        );
        // 图灵api v2接口
        $url = 'http://openapi.tuling123.com/openapi/api/v2';

        //获取文件数据流
        $res = post_curl($url, json_encode($arr));
        $data = json_decode($res,true);
        $result = transmitText($object, $data['results'][0]['values']['text']);
        return $result;
    }

    // 回复图片
    public function eventImg($object)
    {
        $result = transmitImg($object);
        return $result;
    }

    // 事件--文本
    public function eventMsg($object)
    {
        if($object->Event == 'CLICK') {
            switch ($object->EventKey) {
                case 1:
                    $content = '拉取点击事件1';
                    break;
                
                case 2:
                    $content = '拉取点击事件2';
                    break;
                
                default:
                    $content = '默认点击事件';
                    break;
            }
        }else {
            $content = '不是点击事件';
        }
        $result = transmitText($object, $content);
        return $result;
    }

    // 打印数据日志
    public function getLog()
    {
        header('Content-type: text/html;charset=UTF-8');
        $data = get_files_log('log.xml');
        print_r($data);
    }

    // 打印请求日志
    public function getQuery()
    {
        header('Content-type: text/html;charset=UTF-8');
        $data = get_files_log('query.xml');
        print_r($data);
    }

    // 自定义菜单创建
    public function createMenu()
    {
        header('Content-type: text/html;charset=UTF-8');
        $postArr = $GLOBALS['HTTP_RAW_POST_DATA'];
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$this->access_token;
        $data = post_curl($url, $postArr);
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    }

    // 自定义菜单删除
    public function deleteMenu()
    {
        header('Content-type: text/html;charset=UTF-8');
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/delete?access_token='.$this->access_token;
        $data = get_curl($url);
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    }

    // 自定义菜单查询
    public function getMenu()
    {
        header('Content-type: text/html;charset=UTF-8');
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/get?access_token='.$this->access_token;
        $data = get_curl($url);
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    }



}