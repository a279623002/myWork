<?php
return array(
	//'配置项'=>'配置值'
	'apiKey'	=> '60f4900646244ec09e706641975a2ee9',
);